from echo_logger import *


print_info("Hello World!")
print_warn("Hello World!")
print_err("Hello World!")