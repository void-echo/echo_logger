from echo_logger import send_feishu

if __name__ == '__main__':
    send_feishu(title_="test", content_="test")
