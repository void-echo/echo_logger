# Echo Logger

This is a simple echo logger for informative, warning and error messages.

Time and colored printing are supported.

This repository is mostly for my own use, but feel free to use it if you want.